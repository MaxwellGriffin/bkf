<div class="container-fluid before-after-box">
    <div class="row">
        <div class="col-md-6 my-auto">
            <span>Need some cleaning inspiration? You won't believe what Bar Keepers Friend can do.</span>
        </div>
        <div class="col-md-6 text-right">
            <a href="#" class="bkf-button green">Before & After Gallery <i class="fas fa-chevron-right"></i></a>
        </div>
    </div>
</div>