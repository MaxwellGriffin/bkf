<!doctype html>
<html lang="en">

<head>
    <?php wp_head(); ?>
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link href="https://fonts.googleapis.com/css?family=Open+Sans:300,300i,400,400i,600,600i,700,700i,800,800i&display=swap" rel="stylesheet">

    <!-- search engines don't index this site (for dev only) -->
    <meta name="robots" content="noindex, nofollow">
</head>

<body>
    <header>
    </header>