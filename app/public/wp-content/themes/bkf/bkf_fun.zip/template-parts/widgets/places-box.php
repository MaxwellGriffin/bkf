<div class="container-fluid places-box">
    <div class="row">
        <div class="col mobile-left">
            <span class="bigtext">You might be surprised how many places Bar Keepers Friend cleaning products can be used throughout the home!</span>
        </div>
    </div>
    <!-- <div class="row places-spacer"> -->
    <div class="places-spacer">
        <?php include(locate_template('template-parts/widgets/places-box-item.php', false, false)); ?>
        <?php include(locate_template('template-parts/widgets/places-box-item.php', false, false)); ?>
        <?php include(locate_template('template-parts/widgets/places-box-item.php', false, false)); ?>
        <?php include(locate_template('template-parts/widgets/places-box-item.php', false, false)); ?>
    </div>
</div>