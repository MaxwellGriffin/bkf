<!-- <div class="col-md-3 mobile-left place"> -->
<div class="mobile-left place">
    <a href="#" class="floating-card">
        <div class="row">
            <div class="col-4 col-md-12 col-lg-12 col-xl-12">
                <img src="<?php echo get_theme_file_uri(); ?>/images/circle_placeholder.png" alt="">
            </div>
            <div class="col-8 col-md-12 col-lg-12 col-xl-12 mobile-left">
                <h6>Kitchen</h6>
                <p>Make your sink, cooktop, cookware, and countertops sparkle.</p>
                <span>Learn More</span>
            </div>
        </div>
    </a>
</div>